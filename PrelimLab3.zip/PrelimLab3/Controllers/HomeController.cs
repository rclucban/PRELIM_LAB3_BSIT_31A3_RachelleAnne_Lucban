using System;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using PRELIM_LAB3_BSIT_31A3_RachelleAnne_Lucban.Models;

namespace PrelimLab3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<Customer> customerList = new List<Customer>
            {
                new Customer
                {
                    FirstName = "Juan",
                    MiddleName = "Dela",
                    LastName = "Cruz",
                    BirthDay = new DateTime(1990, 5, 15),
                    CustomerId = 1001
                },
                new VipCustomer
                {
                    FirstName = "Maria",
                    MiddleName = "Santos",
                    LastName = "Reyes",
                    BirthDay = new DateTime(1985, 10, 20),
                    CustomerId = 2001,
                    IsVip = true
                },
                new Customer
                {
                    FirstName = "Pedro",
                    MiddleName = "Lim",
                    LastName = "Sy",
                    BirthDay = new DateTime(1992, 1, 25),
                    CustomerId = 1002
                },
                new VipCustomer
                {
                    FirstName = "Anna",
                    MiddleName = "Garcia",
                    LastName = "Chan",
                    BirthDay = new DateTime(1988, 7, 10),
                    CustomerId = 2002,
                    IsVip = true
                }
            };

            ViewBag.CustomerList = customerList;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
