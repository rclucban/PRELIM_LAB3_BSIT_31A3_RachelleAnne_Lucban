﻿using System;

namespace PRELIM_LAB3_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public class BaseEntity : IDescribeable

    {
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public DateTime BirthDay { get; set; }

        public int GetAge()
        {
            var today = DateTime.Today;
            var age = today.Year - BirthDay.Year;
            if (BirthDay.Date > today.AddYears(-age))
            {
                age--;
            }
            return age;
        }

        public string GetFullName()
        {
            return $"{FirstName} {MiddleName} {LastName}";
        }

        public virtual string GetDescription()
        {
            return $"{GetFullName()}, Age: {GetAge()}";
        }
    }
}