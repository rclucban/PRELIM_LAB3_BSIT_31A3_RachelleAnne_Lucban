﻿namespace PRELIM_LAB3_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public interface IDescribeable 
    {
        string GetDescription();
    }
}
