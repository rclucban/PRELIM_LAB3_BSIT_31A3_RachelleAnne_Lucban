﻿namespace PRELIM_LAB3_BSIT_31A3_RachelleAnne_Lucban.Models
{
    public class VipCustomer : Customer
    {
        public bool IsVip { get; set; }

        public override string GetDescription()
        {
            return $"VIP Customer, {GetFullName()} {GetAge()} {CustomerId}";
        }
    }
}
